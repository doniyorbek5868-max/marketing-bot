import os
import json
import asyncio
from datetime import datetime, date
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes, ConversationHandler
)

TOKEN = os.getenv("BOT_TOKEN", "BU_YERGA_TOKENINGIZNI_QOYING")
DATA_FILE = "data.json"

# Conversation states
(ASK_XODIM_ISM, ASK_XODIM_LAV, ASK_XODIM_OYLIK, ASK_XODIM_KUN,
 ASK_LOYIHA_NOM, ASK_LOYIHA_BUDJET, ASK_LOYIHA_PAID,
 ASK_TOLOV_SUMMA, ASK_TOLOV_IZOH,
 ASK_LOYIHA_TOLOV_SUMMA, ASK_LOYIHA_TOLOV_IZOH) = range(11)

# ─── Ma'lumotlar ───────────────────────────────────────────────────────────────

def load():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "xodimlar": [
            {"id":1,"ism":"Sarvar","lav":"Xodim","oylik":0,"kun":1,"tolangan":False},
            {"id":2,"ism":"Oxunjon","lav":"Xodim","oylik":0,"kun":1,"tolangan":False},
            {"id":3,"ism":"Fayzulo","lav":"Xodim","oylik":0,"kun":1,"tolangan":False},
            {"id":4,"ism":"Ergashali","lav":"Xodim","oylik":0,"kun":1,"tolangan":False},
            {"id":5,"ism":"Ofis","lav":"Ofis xarajat","oylik":0,"kun":1,"tolangan":False},
        ],
        "loyihalar": [
            {"id":1,"nom":"Dr. Ismoiljon","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
            {"id":2,"nom":"G'ofurov Klinikasi","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
            {"id":3,"nom":"Dostonbek Ortoped","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
            {"id":4,"nom":"Revmatolog","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
            {"id":5,"nom":"Millymed","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
            {"id":6,"nom":"Ixlosmed","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
            {"id":7,"nom":"G'ayrat Aka","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
            {"id":8,"nom":"Strowbery","budjet":0,"paid":0,"status":"Faol","tolovlar":[]},
        ],
        "tolov_tarixi": [],
        "next_xid": 6,
        "next_lid": 9,
    }

def save(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def fmt(n):
    return f"{int(n):,}".replace(",", " ")

def bugun():
    return date.today().strftime("%Y-%m-%d")

# ─── /start ───────────────────────────────────────────────────────────────────

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    kb = [
        [InlineKeyboardButton("👥 Xodimlar", callback_data="menu_xodim"),
         InlineKeyboardButton("💰 Oyliklar", callback_data="menu_oylik")],
        [InlineKeyboardButton("📁 Loyihalar", callback_data="menu_loyiha"),
         InlineKeyboardButton("🔔 Eslatmalar", callback_data="menu_eslatma")],
        [InlineKeyboardButton("📊 Umumiy hisobot", callback_data="menu_hisobot")],
    ]
    await update.message.reply_text(
        "👋 *Marketing Jamoa Boshqaruv Tizimi*\n\nQuyidagi bo'limlardan birini tanlang:",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )

async def menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "menu_xodim":      await show_xodimlar(query)
    elif data == "menu_oylik":    await show_oyliklar(query)
    elif data == "menu_loyiha":   await show_loyihalar(query)
    elif data == "menu_eslatma":  await show_eslatmalar(query)
    elif data == "menu_hisobot":  await show_hisobot(query)
    elif data == "menu_bosh":     await show_bosh(query)

async def show_bosh(query):
    kb = [
        [InlineKeyboardButton("👥 Xodimlar", callback_data="menu_xodim"),
         InlineKeyboardButton("💰 Oyliklar", callback_data="menu_oylik")],
        [InlineKeyboardButton("📁 Loyihalar", callback_data="menu_loyiha"),
         InlineKeyboardButton("🔔 Eslatmalar", callback_data="menu_eslatma")],
        [InlineKeyboardButton("📊 Umumiy hisobot", callback_data="menu_hisobot")],
    ]
    await query.edit_message_text(
        "👋 *Marketing Jamoa Boshqaruv Tizimi*\n\nQuyidagi bo'limlardan birini tanlang:",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )

# ─── XODIMLAR ─────────────────────────────────────────────────────────────────

async def show_xodimlar(query):
    d = load()
    text = "👥 *Xodimlar ro'yxati*\n\n"
    for x in d["xodimlar"]:
        status = "✅" if x["tolangan"] else "⏳"
        oylik = fmt(x["oylik"]) + " so'm" if x["oylik"] else "kiritilmagan"
        text += f"{status} *{x['ism']}* — {x['lav']}\n"
        text += f"   💵 {oylik} | 📅 Har oy {x['kun']}-kuni\n\n"

    kb = [
        [InlineKeyboardButton("➕ Xodim qo'sh", callback_data="xodim_qosh")],
        [InlineKeyboardButton("✏️ Xodim tahrirlash", callback_data="xodim_tahrir_list")],
        [InlineKeyboardButton("🗑 Xodim o'chirish", callback_data="xodim_ochir_list")],
        [InlineKeyboardButton("🏠 Bosh menyu", callback_data="menu_bosh")],
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

async def show_oyliklar(query):
    d = load()
    today_day = date.today().day
    text = "💰 *Oyliklar holati*\n\n"
    for x in d["xodimlar"]:
        if not x["oylik"]:
            text += f"⚠️ *{x['ism']}* — oylik kiritilmagan\n\n"
            continue
        diff = x["kun"] - today_day
        if x["tolangan"]:
            icon = "✅"
            info = "To'langan"
        elif diff < 0:
            icon = "🔴"
            info = f"{abs(diff)} kun kechikmoqda!"
        elif diff <= 3:
            icon = "🟡"
            info = f"{diff} kun qoldi"
        else:
            icon = "🟢"
            info = f"{diff} kun qoldi"
        text += f"{icon} *{x['ism']}* — {fmt(x['oylik'])} so'm\n"
        text += f"   📅 {x['kun']}-kun | {info}\n\n"

    kb = [
        [InlineKeyboardButton("💸 Oylik to'lash", callback_data="oylik_tola_list")],
        [InlineKeyboardButton("🔄 Qayta belgilash", callback_data="oylik_reset_list")],
        [InlineKeyboardButton("🏠 Bosh menyu", callback_data="menu_bosh")],
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

async def show_loyihalar(query):
    d = load()
    text = "📁 *Loyihalar*\n\n"
    for l in d["loyihalar"]:
        icon = "🟢" if l["status"] == "Faol" else ("✅" if l["status"] == "Yakunlangan" else "🟡")
        if l["budjet"] > 0:
            pct = int(l["paid"] / l["budjet"] * 100)
            qoldi = l["budjet"] - l["paid"]
            bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
            text += f"{icon} *{l['nom']}*\n"
            text += f"   [{bar}] {pct}%\n"
            text += f"   💰 {fmt(l['budjet'])} | ✅ {fmt(l['paid'])} | ⏳ {fmt(qoldi)}\n\n"
        else:
            text += f"{icon} *{l['nom']}* — byudjet kiritilmagan\n\n"

    kb = [
        [InlineKeyboardButton("➕ Yangi loyiha", callback_data="loyiha_qosh")],
        [InlineKeyboardButton("💳 To'lov qo'sh", callback_data="loyiha_tolov_list")],
        [InlineKeyboardButton("✏️ Status o'zgartir", callback_data="loyiha_status_list")],
        [InlineKeyboardButton("🏠 Bosh menyu", callback_data="menu_bosh")],
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

async def show_eslatmalar(query):
    d = load()
    today_day = date.today().day
    text = "🔔 *Eslatmalar*\n\n"
    found = False

    for x in d["xodimlar"]:
        if not x["oylik"] or x["tolangan"]:
            continue
        diff = x["kun"] - today_day
        if diff < 0:
            text += f"🔴 *{x['ism']}* oyligi {abs(diff)} kun kechikmoqda!\n"
            found = True
        elif diff <= 3:
            text += f"🟡 *{x['ism']}* oyligi {x['kun']}-kunda. {diff} kun qoldi.\n"
            found = True

    for l in d["loyihalar"]:
        if l["budjet"] > 0 and l["paid"] < l["budjet"] and l["status"] == "Faol":
            qoldi = l["budjet"] - l["paid"]
            text += f"💳 *{l['nom']}*: {fmt(qoldi)} so'm kutilmoqda.\n"
            found = True
        if l["budjet"] == 0 and l["status"] == "Faol":
            text += f"⚠️ *{l['nom']}*: byudjet kiritilmagan.\n"
            found = True

    if not found:
        text += "✅ Hozircha hech qanday muddatli vazifa yo'q!"

    kb = [[InlineKeyboardButton("🏠 Bosh menyu", callback_data="menu_bosh")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

async def show_hisobot(query):
    d = load()
    total_oylik = sum(x["oylik"] for x in d["xodimlar"])
    tolangan = sum(1 for x in d["xodimlar"] if x["tolangan"] and x["oylik"])
    total_budjet = sum(l["budjet"] for l in d["loyihalar"])
    total_paid = sum(l["paid"] for l in d["loyihalar"])
    faol = sum(1 for l in d["loyihalar"] if l["status"] == "Faol")

    text = f"""📊 *Umumiy hisobot — {date.today().strftime('%d.%m.%Y')}*

👥 *Xodimlar*
├ Jami: {len(d['xodimlar'])} ta
├ Oylik to'langan: {tolangan} ta
├ To'lanmagan: {len(d['xodimlar']) - tolangan} ta
└ Oylik jami: {fmt(total_oylik)} so'm

📁 *Loyihalar*
├ Jami: {len(d['loyihalar'])} ta
├ Faol: {faol} ta
├ Jami shartnoma: {fmt(total_budjet)} so'm
├ Tushgan: {fmt(total_paid)} so'm
└ Kutilayotgan: {fmt(total_budjet - total_paid)} so'm
"""
    kb = [[InlineKeyboardButton("🏠 Bosh menyu", callback_data="menu_bosh")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

# ─── Callback: Oylik to'lash ──────────────────────────────────────────────────

async def cb_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    # Bosh menyu
    if data.startswith("menu_"):
        await menu(update, ctx)
        return

    d = load()

    # Oylik to'lash — ro'yxat
    if data == "oylik_tola_list":
        kb = [[InlineKeyboardButton(x["ism"]+" — "+fmt(x["oylik"])+" so'm",
               callback_data=f"oylik_tola_{x['id']}")] for x in d["xodimlar"] if x["oylik"] and not x["tolangan"]]
        kb.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu_oylik")])
        await query.edit_message_text("To'lash uchun xodimni tanlang:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if data.startswith("oylik_tola_") and not data.endswith("list"):
        xid = int(data.split("_")[-1])
        x = next((x for x in d["xodimlar"] if x["id"] == xid), None)
        if x:
            x["tolangan"] = True
            d["tolov_tarixi"].append({"xodim": x["ism"], "summa": x["oylik"], "izoh": "Oylik to'lovi", "sana": bugun()})
            save(d)
            await query.edit_message_text(
                f"✅ *{x['ism']}* ga {fmt(x['oylik'])} so'm oylik to'landi!",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Oyliklar", callback_data="menu_oylik")]]),
                parse_mode="Markdown"
            )
        return

    # Oylik reset
    if data == "oylik_reset_list":
        kb = [[InlineKeyboardButton(x["ism"], callback_data=f"oylik_reset_{x['id']}")] for x in d["xodimlar"] if x["tolangan"]]
        kb.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu_oylik")])
        await query.edit_message_text("Qayta belgilash uchun xodim:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if data.startswith("oylik_reset_"):
        xid = int(data.split("_")[-1])
        x = next((x for x in d["xodimlar"] if x["id"] == xid), None)
        if x:
            x["tolangan"] = False
            save(d)
            await query.edit_message_text(
                f"🔄 *{x['ism']}* oyligi qayta to'lanmagan deb belgilandi.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Oyliklar", callback_data="menu_oylik")]]),
                parse_mode="Markdown"
            )
        return

    # Xodim o'chirish
    if data == "xodim_ochir_list":
        kb = [[InlineKeyboardButton("🗑 "+x["ism"], callback_data=f"xodim_ochir_{x['id']}")] for x in d["xodimlar"]]
        kb.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu_xodim")])
        await query.edit_message_text("O'chirish uchun xodimni tanlang:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if data.startswith("xodim_ochir_"):
        xid = int(data.split("_")[-1])
        x = next((x for x in d["xodimlar"] if x["id"] == xid), None)
        if x:
            d["xodimlar"] = [i for i in d["xodimlar"] if i["id"] != xid]
            save(d)
            await query.edit_message_text(
                f"🗑 *{x['ism']}* o'chirildi.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Xodimlar", callback_data="menu_xodim")]]),
                parse_mode="Markdown"
            )
        return

    # Xodim tahrirlash
    if data == "xodim_tahrir_list":
        kb = [[InlineKeyboardButton("✏️ "+x["ism"], callback_data=f"xodim_tahrir_{x['id']}")] for x in d["xodimlar"]]
        kb.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu_xodim")])
        await query.edit_message_text("Tahrirlash uchun xodimni tanlang:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if data.startswith("xodim_tahrir_"):
        xid = int(data.split("_")[-1])
        ctx.user_data["tahrir_xid"] = xid
        x = next((x for x in d["xodimlar"] if x["id"] == xid), None)
        await query.edit_message_text(
            f"✏️ *{x['ism']}* tahrirlash\n\nYangi oylikni kiriting (so'mda):\n_Misol: 3500000_",
            parse_mode="Markdown"
        )
        ctx.user_data["conv_state"] = "tahrir_oylik"
        return

    # Loyiha to'lov
    if data == "loyiha_tolov_list":
        kb = [[InlineKeyboardButton(l["nom"], callback_data=f"ltolov_{l['id']}")] for l in d["loyihalar"] if l["status"] == "Faol"]
        kb.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu_loyiha")])
        await query.edit_message_text("To'lov qo'shish uchun loyihani tanlang:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if data.startswith("ltolov_"):
        lid = int(data.split("_")[-1])
        ctx.user_data["tolov_lid"] = lid
        l = next((l for l in d["loyihalar"] if l["id"] == lid), None)
        await query.edit_message_text(
            f"💳 *{l['nom']}*\n\nTo'lov summasini kiriting (so'mda):\n_Misol: 2000000_",
            parse_mode="Markdown"
        )
        ctx.user_data["conv_state"] = "loyiha_tolov_summa"
        return

    # Loyiha status
    if data == "loyiha_status_list":
        kb = [[InlineKeyboardButton(l["nom"]+" ["+l["status"]+"]", callback_data=f"lstatus_{l['id']}")] for l in d["loyihalar"]]
        kb.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu_loyiha")])
        await query.edit_message_text("Status o'zgartirish uchun loyihani tanlang:", reply_markup=InlineKeyboardMarkup(kb))
        return

    if data.startswith("lstatus_"):
        lid = int(data.split("_")[-1])
        l = next((l for l in d["loyihalar"] if l["id"] == lid), None)
        statuses = ["Faol", "Kutilmoqda", "Yakunlangan"]
        kb = [[InlineKeyboardButton(s, callback_data=f"lsetstatus_{lid}_{s}")] for s in statuses]
        kb.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu_loyiha")])
        await query.edit_message_text(f"*{l['nom']}* uchun yangi status:", reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
        return

    if data.startswith("lsetstatus_"):
        parts = data.split("_")
        lid = int(parts[1])
        status = parts[2]
        l = next((l for l in d["loyihalar"] if l["id"] == lid), None)
        if l:
            l["status"] = status
            save(d)
            await query.edit_message_text(
                f"✅ *{l['nom']}* statusi *{status}* ga o'zgartirildi.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Loyihalar", callback_data="menu_loyiha")]]),
                parse_mode="Markdown"
            )
        return

# ─── Matn xabarlari (qo'shish jarayoni) ──────────────────────────────────────

async def text_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    state = ctx.user_data.get("conv_state")
    text = update.message.text.strip()
    d = load()

    # Xodim qo'shish
    if state == "xodim_ism":
        ctx.user_data["yangi_xodim"] = {"ism": text}
        ctx.user_data["conv_state"] = "xodim_lav"
        await update.message.reply_text("Lavozimini kiriting:\n_Misol: SMM Mutaxassis_", parse_mode="Markdown")

    elif state == "xodim_lav":
        ctx.user_data["yangi_xodim"]["lav"] = text
        ctx.user_data["conv_state"] = "xodim_oylik"
        await update.message.reply_text("Oylik maoshini kiriting (so'mda):\n_Misol: 3500000_", parse_mode="Markdown")

    elif state == "xodim_oylik":
        try:
            oylik = int(text.replace(" ", "").replace(",", ""))
        except:
            await update.message.reply_text("❌ Raqam kiriting. Misol: 3500000")
            return
        ctx.user_data["yangi_xodim"]["oylik"] = oylik
        ctx.user_data["conv_state"] = "xodim_kun"
        await update.message.reply_text("Oylik qaysi kuni to'lanadi? (1-31):\n_Misol: 25_", parse_mode="Markdown")

    elif state == "xodim_kun":
        try:
            kun = int(text)
            assert 1 <= kun <= 31
        except:
            await update.message.reply_text("❌ 1 dan 31 gacha raqam kiriting.")
            return
        x = ctx.user_data["yangi_xodim"]
        x["id"] = d["next_xid"]
        x["kun"] = kun
        x["tolangan"] = False
        d["xodimlar"].append(x)
        d["next_xid"] += 1
        save(d)
        ctx.user_data.clear()
        await update.message.reply_text(
            f"✅ *{x['ism']}* qo'shildi!\n💵 {fmt(x['oylik'])} so'm | 📅 Har oy {kun}-kuni",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("👥 Xodimlar", callback_data="menu_xodim"), InlineKeyboardButton("🏠 Menyu", callback_data="menu_bosh")]]),
        )

    # Xodim tahrirlash
    elif state == "tahrir_oylik":
        try:
            oylik = int(text.replace(" ", "").replace(",", ""))
        except:
            await update.message.reply_text("❌ Raqam kiriting.")
            return
        xid = ctx.user_data.get("tahrir_xid")
        x = next((x for x in d["xodimlar"] if x["id"] == xid), None)
        if x:
            x["oylik"] = oylik
            ctx.user_data["conv_state"] = "tahrir_kun"
            save(d)
            await update.message.reply_text(f"✅ Oylik yangilandi. Endi to'lov kunini kiriting (1-31):")
        return

    elif state == "tahrir_kun":
        try:
            kun = int(text)
            assert 1 <= kun <= 31
        except:
            await update.message.reply_text("❌ 1-31 orasida raqam kiriting.")
            return
        xid = ctx.user_data.get("tahrir_xid")
        x = next((x for x in d["xodimlar"] if x["id"] == xid), None)
        if x:
            x["kun"] = kun
            save(d)
        ctx.user_data.clear()
        await update.message.reply_text(
            f"✅ *{x['ism']}* yangilandi: {fmt(x['oylik'])} so'm | {kun}-kun",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("👥 Xodimlar", callback_data="menu_xodim")]]),
        )

    # Loyiha qo'shish
    elif state == "loyiha_nom":
        ctx.user_data["yangi_loyiha"] = {"nom": text}
        ctx.user_data["conv_state"] = "loyiha_budjet"
        await update.message.reply_text("Umumiy byudjetni kiriting (so'mda):\n_Misol: 5000000_", parse_mode="Markdown")

    elif state == "loyiha_budjet":
        try:
            budjet = int(text.replace(" ", "").replace(",", ""))
        except:
            await update.message.reply_text("❌ Raqam kiriting.")
            return
        ctx.user_data["yangi_loyiha"]["budjet"] = budjet
        ctx.user_data["conv_state"] = "loyiha_paid"
        await update.message.reply_text("Hozircha qancha pul tushdi? (bo'lmasa 0 kiriting):")

    elif state == "loyiha_paid":
        try:
            paid = int(text.replace(" ", "").replace(",", ""))
        except:
            await update.message.reply_text("❌ Raqam kiriting.")
            return
        l = ctx.user_data["yangi_loyiha"]
        l["id"] = d["next_lid"]
        l["paid"] = paid
        l["status"] = "Faol"
        l["tolovlar"] = [{"summa": paid, "izoh": "Boshlang'ich to'lov", "sana": bugun()}] if paid else []
        d["loyihalar"].append(l)
        d["next_lid"] += 1
        save(d)
        ctx.user_data.clear()
        qoldi = l["budjet"] - l["paid"]
        await update.message.reply_text(
            f"✅ *{l['nom']}* qo'shildi!\n💰 {fmt(l['budjet'])} so'm | ✅ {fmt(l['paid'])} | ⏳ {fmt(qoldi)}",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📁 Loyihalar", callback_data="menu_loyiha")]]),
        )

    # Loyiha to'lov
    elif state == "loyiha_tolov_summa":
        try:
            summa = int(text.replace(" ", "").replace(",", ""))
        except:
            await update.message.reply_text("❌ Raqam kiriting.")
            return
        ctx.user_data["tolov_summa"] = summa
        ctx.user_data["conv_state"] = "loyiha_tolov_izoh"
        await update.message.reply_text("Izoh kiriting:\n_Misol: Ikkinchi bosqich to'lovi_", parse_mode="Markdown")

    elif state == "loyiha_tolov_izoh":
        izoh = text
        lid = ctx.user_data.get("tolov_lid")
        summa = ctx.user_data.get("tolov_summa", 0)
        l = next((l for l in d["loyihalar"] if l["id"] == lid), None)
        if l:
            l["paid"] += summa
            l["tolovlar"].append({"summa": summa, "izoh": izoh, "sana": bugun()})
            if l["budjet"] > 0 and l["paid"] >= l["budjet"]:
                l["status"] = "Yakunlangan"
            save(d)
            qoldi = l["budjet"] - l["paid"]
        ctx.user_data.clear()
        await update.message.reply_text(
            f"✅ *{l['nom']}* ga {fmt(summa)} so'm to'lov qo'shildi!\n⏳ Qoldi: {fmt(max(qoldi,0))} so'm",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📁 Loyihalar", callback_data="menu_loyiha")]]),
        )

    else:
        await update.message.reply_text(
            "Asosiy menyu uchun /start bosing.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Menyu", callback_data="menu_bosh")]]),
        )

# ─── /xodim_qosh command ──────────────────────────────────────────────────────

async def cmd_xodim_qosh(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["conv_state"] = "xodim_ism"
    await update.message.reply_text("👤 Xodim ismini kiriting:")

async def cb_xodim_qosh(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    ctx.user_data["conv_state"] = "xodim_ism"
    await query.edit_message_text("👤 Yangi xodim ismini kiriting:")

async def cb_loyiha_qosh(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    ctx.user_data["conv_state"] = "loyiha_nom"
    await query.edit_message_text("📁 Yangi loyiha nomini kiriting:")

# ─── Kunlik eslatma (scheduler) ───────────────────────────────────────────────

async def kunlik_eslatma(ctx: ContextTypes.DEFAULT_TYPE):
    chat_id = ctx.job.data
    d = load()
    today_day = date.today().day
    msgs = []

    for x in d["xodimlar"]:
        if not x["oylik"] or x["tolangan"]:
            continue
        diff = x["kun"] - today_day
        if diff < 0:
            msgs.append(f"🔴 *{x['ism']}* oyligi {abs(diff)} kun kechikmoqda!")
        elif diff <= 3:
            msgs.append(f"🟡 *{x['ism']}* oyligi {x['kun']}-kunda. {diff} kun qoldi.")

    for l in d["loyihalar"]:
        if l["budjet"] > 0 and l["paid"] < l["budjet"] and l["status"] == "Faol":
            msgs.append(f"💳 *{l['nom']}*: {fmt(l['budjet'] - l['paid'])} so'm kutilmoqda.")

    if msgs:
        text = "🔔 *Bugungi eslatmalar:*\n\n" + "\n".join(msgs)
        await ctx.bot.send_message(chat_id=chat_id, text=text, parse_mode="Markdown")

async def post_init(app: Application):
    pass

# ─── /eslatma_yoq ─────────────────────────────────────────────────────────────

async def cmd_eslatma(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    ctx.job_queue.run_daily(
        kunlik_eslatma,
        time=datetime.strptime("09:00", "%H:%M").time(),
        data=chat_id,
        name=str(chat_id),
    )
    await update.message.reply_text("✅ Kunlik eslatmalar yoqildi! Har kuni soat 09:00 da yuboriladi.")

# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("eslatma", cmd_eslatma))
    app.add_handler(CommandHandler("xodim_qosh", cmd_xodim_qosh))

    app.add_handler(CallbackQueryHandler(cb_xodim_qosh, pattern="^xodim_qosh$"))
    app.add_handler(CallbackQueryHandler(cb_loyiha_qosh, pattern="^loyiha_qosh$"))
    app.add_handler(CallbackQueryHandler(cb_handler))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))

    print("✅ Bot ishga tushdi!")
    app.run_polling()

if __name__ == "__main__":
    main()
