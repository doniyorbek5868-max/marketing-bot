# Marketing Jamoa Telegram Bot — O'rnatish Yo'riqnomasi

## 1-QADAM: Token olish (2 daqiqa)

1. Telegramda **@BotFather** ga yozing
2. `/newbot` yuboring
3. Bot nomi: `Marketing Jamoa`
4. Username: `sizning_marketing_bot` (oxiri _bot bilan tugashi shart)
5. BotFather sizga shunday token beradi:
   `1234567890:AAHdqTcvCH1vGWJxfSeofSs0K67PAEPHE4t`
6. Bu tokenni saqlab qo'ying!

---

## 2-QADAM: bot.py faylini tahrirlash

`bot.py` faylni oching va bu qatorni toping:

```
TOKEN = os.getenv("BOT_TOKEN", "BU_YERGA_TOKENINGIZNI_QOYING")
```

`BU_YERGA_TOKENINGIZNI_QOYING` o'rniga o'z tokeningizni qo'ying:

```
TOKEN = os.getenv("BOT_TOKEN", "1234567890:AAHdqTcvCH1vGWJxfSeofSs0K67PAEPHE4t")
```

---

## 3-QADAM: Railway.app da ishga tushirish (BEPUL, kod yozmasdan)

### Railway.app — bu nima?
Internet'da botingizni doimo yoqiq ushlab turadigan bepul server.

### Qadamlar:

1. **https://railway.app** saytiga kiring
2. **"Login with GitHub"** bosing
3. GitHub yo'q bo'lsa → **https://github.com** da ro'yxatdan o'ting (bepul)
4. Railway'ga qaytib "Login with GitHub" bosing

5. **"New Project"** → **"Deploy from GitHub repo"** bosing
6. **"Configure GitHub App"** → GitHub'ga ruxsat bering

7. GitHub'da yangi repository yarating:
   - **https://github.com/new** ga kiring
   - Repository name: `marketing-bot`
   - **"Create repository"** bosing

8. Kompyuteringizga **GitHub Desktop** o'rnating:
   - https://desktop.github.com dan yuklab oling

9. GitHub Desktop'da:
   - "Clone a repository" → `marketing-bot` ni tanlang
   - `bot.py` va `requirements.txt` fayllarni o'sha papkaga ko'chiring
   - "Commit to main" → "Push origin" bosing

10. Railway'da:
    - Siz yaratgan `marketing-bot` repository'ni tanlang
    - **"Deploy Now"** bosing

11. Railway dashboard'da **"Variables"** tab:
    - `BOT_TOKEN` = sizning tokeningiz
    - **"Add"** bosing

12. **"Deploy"** → 2-3 daqiqada bot ishga tushadi! ✅

---

## 4-QADAM: Eslatmalarni yoqish

Botga `/eslatma` yuboring — shundan keyin har kuni soat 09:00 da
kechikkan oyliklar va to'lanmagan loyihalar haqida xabar keladi.

---

## Bot buyruqlari:

| Buyruq | Nima qiladi |
|--------|-------------|
| /start | Asosiy menyu |
| /eslatma | Kunlik eslatmalarni yoqish |
| /xodim_qosh | Yangi xodim qo'shish |

---

## Muammo bo'lsa:

Telegram'da yozing: botingizga `/start` yuboring.
Agar javob bermasa — Railway dashboard'da "Logs" ni tekshiring.

---

## Bot nima qila oladi?

✅ Xodimlar ro'yxatini ko'rish
✅ Xodim qo'shish, tahrirlash, o'chirish
✅ Har bir xodimning oyligini va to'lov kunini belgilash
✅ Oylik to'lash / to'lanmagan deb belgilash
✅ To'lov tarixi
✅ Loyiha byudjeti va tushgan pulni kuzatish
✅ Loyihaga to'lov qo'shish
✅ Loyiha statusini o'zgartirish (Faol / Kutilmoqda / Yakunlangan)
✅ Har kuni soat 09:00 da avtomatik eslatma
✅ Umumiy moliyaviy hisobot
